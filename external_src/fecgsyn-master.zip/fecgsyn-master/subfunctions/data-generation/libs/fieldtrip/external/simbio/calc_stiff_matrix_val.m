function [varargout] = calc_stiff_matrix_val(varargin)

% CALC_STIFF_MATRIX is implemented as mex file
%
% $Id$

error('The mex file %s is missing', [mfilename '.' mexext]);
